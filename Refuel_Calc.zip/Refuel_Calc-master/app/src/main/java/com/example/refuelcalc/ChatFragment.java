package com.example.refuelcalc;


import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import java.util.ArrayList;
import java.util.HashMap;

public class ChatFragment extends Fragment {

    public static String driverID = "";

    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;
View v;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        sharedPreferences = getContext().getSharedPreferences("MyPref", 0);
        editor = sharedPreferences.edit();
        driverID = sharedPreferences.getString("driverID","");

        v=inflater.inflate(R.layout.fragment_chat,container,false);
        DBHelper db = new DBHelper(getContext());
        ArrayList<HashMap<String, String>> userList = db.GetUsers(driverID);
        ListView lv = (ListView)v.findViewById(R.id.user_list);
        ListAdapter adapter = new SimpleAdapter(getContext(), userList, R.layout.list_row,new String[]{"did","name","phone","license"}, new int[]{R.id.did,R.id.name, R.id.phone, R.id.licence});
        lv.setAdapter(adapter);
        return v;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
    }
}
