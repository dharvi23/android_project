package com.example.refuelcalc;

import  b android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.DatabaseErrorHandler;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public class Database extends SQLiteOpenHelper {

    public Database(Context context){
        super(context, "CIE2_Database", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL("create table drivers (firstName Text, lastName Text, userName Text, password Text)");
        sqLiteDatabase.execSQL("create table driverEntry (userName, Text, date Text, volume double, rupeesPerLitre double, odometerReading double)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("drop table if exists drivers");
        sqLiteDatabase.execSQL("drop table if exists driverEntry");
    }

    public boolean registerDriver(String firstName, String lastName, String userName, String password){
        // this function will be called when driver clicks register
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("firstName", firstName);
        contentValues.put("lastName", lastName);
        contentValues.put("userName", userName);
        contentValues.put("password", password);

        long result = sqLiteDatabase.insert("drivers", null, contentValues);
        if(result == -1)
            return false;
        return true;
    }

    public boolean loginDriver(String userName, String password){
        // this function will be called when user is trying to login as a driver
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        Cursor cursor =
                sqLiteDatabase.rawQuery("Select * from drivers where userName = ? and password = ?", new String[]{userName, password});

        if(cursor.getCount() > 0)
            return true;
        return false;
    }

    public boolean checkUserName(String userName){
        // checking if user name already exists or not
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        Cursor cursor =
                sqLiteDatabase.rawQuery("Select * from drivers where userName = ?", new String[]{userName});
        if(cursor.getCount() > 0)
            return true;
        return false;
    }

    // driver side
    public boolean driverAddEntry(String userName, String date, double volume, double rupeesPerLitre, double odometerReading){

        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("userName", userName);
        contentValues.put("date", date);
        contentValues.put("volume", volume);
        contentValues.put("rupeesPerLitre", rupeesPerLitre);
        contentValues.put("odometerReading", odometerReading);

        long result = sqLiteDatabase.insert("driverResult", null, contentValues);
        if(result == -1)
            return false;
        return true;
    }
}
