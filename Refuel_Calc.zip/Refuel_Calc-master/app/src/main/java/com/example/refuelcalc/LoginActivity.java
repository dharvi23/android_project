package com.example.refuelcalc;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.airbnb.lottie.LottieAnimationView;

public class LoginActivity extends AppCompatActivity implements View.OnClickListener {
    LottieAnimationView lottieAnimationView;

    private Button loginbtn;
    private EditText driverID, pass;
    private TextView registerText;
    DBHelper db;

    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        getSupportActionBar().setTitle("Login");

        sharedPreferences = getApplication().getSharedPreferences("MyPref", 0);
        editor = sharedPreferences.edit();

        lottieAnimationView = findViewById(R.id.user);
        lottieAnimationView.animate().translationY(0).setDuration(2000).setStartDelay(5000);

        loginbtn = (Button) findViewById(R.id.btnlogin);
        loginbtn.setOnClickListener(this);

        driverID = (EditText) findViewById(R.id.username);
        pass = (EditText) findViewById(R.id.password);
        registerText = (TextView) findViewById(R.id.register);
        registerText.setOnClickListener(this);
        db = new DBHelper(this);

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {

            }
        },3000);
    };

    @Override
    public void onClick(View view) {
        if (view.getId() == R.id.btnlogin) {
            Log.d("MYTAGS",driverID.getText().toString() + pass.getText().toString());
            if (driverID.getText().toString().equals("admin@gmail.com") && pass.getText().toString().equals("admin123")) {
                Toast toast = Toast.makeText(getApplicationContext(), "Login Successfully", Toast.LENGTH_SHORT);
                toast.show();
                startActivity(new Intent(LoginActivity.this, SplashScreenActivity2.class));
            }
            else if(db.checkUser(driverID.getText().toString(),pass.getText().toString())){
                Toast toast = Toast.makeText(getApplicationContext(), "Login Successfully", Toast.LENGTH_SHORT);
                toast.show();
                editor.putString("driverID", driverID.getText().toString());
                editor.commit();
                String driverID10 = sharedPreferences.getString("driverID","");
                Log.i("MYTAG"," "+driverID10);
                startActivity(new Intent(LoginActivity.this, SplashScreenActivity2.class));
            }
            else {
                Toast toast = Toast.makeText(getApplicationContext(), "EmailId Password Incorrect", Toast.LENGTH_SHORT);
                toast.show();
            }
        } else if (view.getId() == R.id.register){
            startActivity(new Intent(LoginActivity.this,RegisterActivity.class));
        }
    }
}