package com.example.refuelcalc;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.airbnb.lottie.LottieAnimationView;

public class RegisterActivity extends AppCompatActivity implements View.OnClickListener {
    LottieAnimationView lottieAnimationView;

    Button registerbtn;
    EditText name,password,phone,license,driverID;
    DBHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        getSupportActionBar().setTitle("Register");

        lottieAnimationView = findViewById(R.id.registeruser);
        lottieAnimationView.animate().translationY(0).setDuration(2000).setStartDelay(5000);

        registerbtn = findViewById(R.id.register_btn);
        registerbtn.setOnClickListener(this);

        name = findViewById(R.id.register_name);
        password = findViewById(R.id.register_password);
        phone = findViewById(R.id.register_phone);
        license = findViewById(R.id.register_driving_license);
        driverID = findViewById(R.id.register_driver_id);
        db = new DBHelper(this);

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {

            }
        },3000);
    }

    @Override
    public void onClick(View view) {
        String name1 = name.getText().toString();
        String password1 = password.getText().toString();
        String phone1 = phone.getText().toString();
        String licence1= license.getText().toString();
        String did1= driverID.getText().toString();
        System.out.println(did1);
        if(db.checkUserName(did1)){
            Toast.makeText(RegisterActivity.this,"User already exists",Toast.LENGTH_SHORT).show();
            Log.i("MYTAGS","exists");
            return;
        }
        Boolean checkinsertdata=db.insertuserdata(name1,password1,phone1,licence1,did1);
        Log.i("MYTAGS",""+checkinsertdata);

        if(checkinsertdata==true){
            System.out.println("inside");
            Toast.makeText(RegisterActivity.this,"New Entry Added",Toast.LENGTH_SHORT).show();
            startActivity(new Intent(RegisterActivity.this,LoginActivity.class));
        }
        else{
            System.out.println("inside2");
            Toast.makeText(RegisterActivity.this,"Entry Not Added",Toast.LENGTH_SHORT).show();
        }
    }
}